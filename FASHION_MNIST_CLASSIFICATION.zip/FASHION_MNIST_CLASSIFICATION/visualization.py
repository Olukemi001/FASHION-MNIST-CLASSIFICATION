#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np  # Importing numpy for numerical operations
import matplotlib.pyplot as plt  # Importing matplotlib for plotting
from matplotlib import cm  # Importing colormap module for enhanced visuals

def visualize_predictions(model, x_test, y_test, sample_indices, class_names):
    """
    Visualizes predictions for the given sample indices.

    Parameters:
    - model: Trained model to use for making predictions.
    - x_test: Test dataset (features) for input images.
    - y_test: Test dataset (labels) for true output values.
    - sample_indices: List of indices of images from x_test to visualize.
    - class_names: List of class names corresponding to the output classes.

    This function selects a few test images, makes predictions using the model,
    and displays the true and predicted classes with confidence percentages.
    """
    try:
        # Select specific images from the test dataset using the sample indices
        sample_images = x_test[sample_indices]
        
        # Retrieve the true labels for the selected samples
        sample_labels = y_test[sample_indices]

        # Use the model to predict the class probabilities for the sample images
        predictions = model.predict(sample_images)

        # Convert predicted probabilities to class indices
        predicted_classes = np.argmax(predictions, axis=1)  # Get the index of the highest probability
        # Convert one-hot encoded true labels to class indices
        true_classes = np.argmax(sample_labels, axis=1)  # Get the true class index

        # Create a figure for visualizing the images
        plt.figure(figsize=(10, 5))  # Set the figure size
        for i, idx in enumerate(sample_indices):
            # Create a subplot for each sample image
            plt.subplot(1, len(sample_indices), i + 1)  # 1 row, as many columns as samples
            
            # Display the sample image with a colormap for better visualization
            plt.imshow(
                sample_images[i].reshape(28, 28),  # Reshape from (28, 28, 1) to (28, 28)
                cmap=cm.viridis,  # Apply the 'viridis' color map for visualization
                interpolation='bilinear'  # Smoothen the display of pixelated images
            )
            
            # Add a title showing the true label, predicted label, and confidence
            plt.title(
                f"True: {class_names[true_classes[i]]}\n"  # True class name
                f"Predicted: {class_names[predicted_classes[i]]}\n"  # Predicted class name
                f"Confidence: {100 * np.max(predictions[i]):.2f}%"  # Confidence percentage
            )
            
            # Hide the axes for a cleaner look
            plt.axis('off')

        # Adjust the layout to ensure all subplots fit nicely
        plt.tight_layout()
        
        # Display the figure
        plt.show()

    except Exception as e:
        # Catch and display any errors that occur during the visualization process
        print(f"Error during visualization: {e}")

