#!/usr/bin/env python
# coding: utf-8

# In[1]:


from data_processing import load_and_preprocess_data
from model_training import create_model, train_model, evaluate_model
from visualization import visualize_predictions

# Class names for Fashion MNIST
class_names = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]

# Load and preprocess data
x_train, y_train, x_test, y_test = load_and_preprocess_data()

# Ensure data is loaded properly
if x_train is None or y_train is None:
    raise RuntimeError("Failed to load data!")

# Create model
model = create_model()

# Train model
history = train_model(model, x_train, y_train, epochs=10)

# Evaluate model
test_loss, test_accuracy = evaluate_model(model, x_test, y_test)
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")

# Visualize predictions
sample_indices = [0, 1,2,3] 
visualize_predictions(model, x_test, y_test, sample_indices, class_names)

