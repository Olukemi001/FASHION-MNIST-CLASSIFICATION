#!/usr/bin/env python
# coding: utf-8

# In[3]:


from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout

def create_model():
    """
    Creates and compiles a CNN model for the Fashion MNIST dataset.
    Returns the compiled model.
    """
    try:
        model = Sequential([
            Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
            MaxPooling2D(pool_size=(2, 2)),
            Conv2D(64, (3, 3), activation='relu'),
            MaxPooling2D(pool_size=(2, 2)),
            Flatten(),
            Dense(128, activation='relu'),
            Dropout(0.5),
            Dense(10, activation='softmax')
        ])
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        return model

    except Exception as e:
        print(f"Error creating the model: {e}")
        return None

def train_model(model, x_train, y_train, epochs=10, batch_size=64, validation_split=0.2):
    """
    Trains the model on the training data.
    Returns the training history.
    """
    try:
        history = model.fit(
            x_train, y_train,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=validation_split
        )
        return history
    except Exception as e:
        print(f"Error during model training: {e}")
        return None

def evaluate_model(model, x_test, y_test):
    """
    Evaluates the model on the test dataset.
    Returns test loss and accuracy.
    """
    try:
        test_loss, test_accuracy = model.evaluate(x_test, y_test)
        return test_loss, test_accuracy
    except Exception as e:
        print(f"Error during model evaluation: {e}")
        return None, None

