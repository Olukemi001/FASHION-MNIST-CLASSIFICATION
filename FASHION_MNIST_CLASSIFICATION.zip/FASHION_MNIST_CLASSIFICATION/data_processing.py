#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np  # Importing numpy for numerical operations
from keras.datasets import fashion_mnist  # Importing the Fashion MNIST dataset from Keras
from keras.utils import to_categorical  # Importing the utility function for one-hot encoding labels

# Function to load and preprocess data
def load_and_preprocess_data():
    """
    Loads the Fashion MNIST dataset and preprocesses it for training.
    Returns normalized and reshaped training and test datasets.
    """
    try:
        # Load the Fashion MNIST dataset
        # This function returns two tuples: (x_train, y_train) for training data and labels,
        # and (x_test, y_test) for testing data and labels.
        (x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()

        # Normalize the image data by dividing each pixel by 255.0
        # The pixel values range from 0 to 255, so dividing by 255 scales them to [0, 1]
        x_train = x_train / 255.0
        x_test = x_test / 255.0

        # Reshape the image arrays to add a channel dimension
        # Fashion MNIST images are 28x28 grayscale, and CNNs expect a 4D tensor as input:
        # (samples, height, width, channels)
        # The '-1' in the reshape means that it will automatically calculate the size of the first dimension (number of samples)
        x_train = x_train.reshape(-1, 28, 28, 1)  # Reshape training images to have a channel dimension
        x_test = x_test.reshape(-1, 28, 28, 1)  # Reshape test images similarly

        # One-hot encode the labels
        # The labels are integers in the range [0, 9], representing the 10 classes (e.g., T-shirt, trouser, etc.)
        # The to_categorical function converts these integers to one-hot encoded vectors.
        y_train = to_categorical(y_train, 10)
        y_test = to_categorical(y_test, 10)

        # Return the preprocessed data (training and test images and labels)
        return x_train, y_train, x_test, y_test

    except Exception as e:
        # Handle any exceptions that occur during the data loading and preprocessing
        print(f"Error during data loading and preprocessing: {e}")
        return None, None, None, None  # Return None if there was an error

