# Install and load necessary libraries
install_keras <- function() {
  if (!requireNamespace("keras", quietly = TRUE)) {
    install.packages("keras")
  }
  library(keras)
  if (!tensorflow::tf$config$has_tensorflow()) {
    install_keras()
  }
}

install_keras()  # Ensure the packages are installed and loaded

# Load necessary libraries
library(keras)
library(tensorflow)

# Load and preprocess data
load_and_preprocess_data <- function() {
  # Load Fashion MNIST dataset
  data <- dataset_fashion_mnist()
  x_train <- data$train$x
  y_train <- data$train$y
  x_test <- data$test$x
  y_test <- data$test$y
  
  # Normalize the image data
  x_train <- x_train / 255
  x_test <- x_test / 255
  
  # Reshape the images to have a channel dimension (28x28x1)
  x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
  x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))
  
  # One-hot encode the labels
  y_train <- to_categorical(y_train, 10)
  y_test <- to_categorical(y_test, 10)
  
  return(list(x_train = x_train, y_train = y_train, x_test = x_test, y_test = y_test))
}

# Create the model
create_model <- function() {
  model <- keras_model_sequential() %>%
    layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
    layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    layer_flatten() %>%
    layer_dense(units = 128, activation = 'relu') %>%
    layer_dropout(rate = 0.5) %>%
    layer_dense(units = 10, activation = 'softmax')
  
  model %>%
    compile(optimizer = 'adam', loss = 'categorical_crossentropy', metrics = c('accuracy'))
  
  return(model)
}

# Train the model
train_model <- function(model, x_train, y_train, epochs = 10, batch_size = 64, validation_split = 0.2) {
  history <- model %>%
    fit(x_train, y_train, epochs = epochs, batch_size = batch_size, validation_split = validation_split)
  return(history)
}

# Evaluate the model
evaluate_model <- function(model, x_test, y_test) {
  evaluation <- model %>%
    evaluate(x_test, y_test)
  return(evaluation)
}

# Visualize predictions
visualize_predictions <- function(model, x_test, y_test, sample_indices, class_names) {
  predictions <- model %>% predict(x_test[sample_indices, , , drop = FALSE])
  predicted_classes <- apply(predictions, 1, which.max) - 1  # Convert to class indices
  true_classes <- apply(y_test[sample_indices, , drop = FALSE], 1, which.max) - 1  # True class indices
  
  par(mfrow = c(1, length(sample_indices)))
  for (i in 1:length(sample_indices)) {
    idx <- sample_indices[i]
    img <- x_test[idx, , , drop = FALSE]
    
    # Plot image
    image(t(apply(img[,,1], 2, rev)), col = grey.colors(255), axes = FALSE)
    title <- paste("True:", class_names[true_classes[i] + 1], 
                   "\nPredicted:", class_names[predicted_classes[i] + 1], 
                   "\nConfidence:", round(100 * max(predictions[i]), 2), "%")
    title(main = title)
  }
}

# Class names for Fashion MNIST
class_names <- c("T-shirt/top", "Trouser", "Pullover", "Dress", "Coat", 
                 "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot")

# Load and preprocess data
data <- load_and_preprocess_data()

# Create model
model <- create_model()

# Train model
history <- train_model(model, data$x_train, data$y_train, epochs = 10)

# Evaluate model
evaluation <- evaluate_model(model, data$x_test, data$y_test)
cat("Test Accuracy:", evaluation[2] * 100, "%\n")

# Visualize predictions
sample_indices <- c(1, 2, 3, 4)
visualize_predictions(model, data$x_test, data$y_test, sample_indices, class_names)
